function saveNewEmployee() {
    // adicionar dados do funcionario no bd
}

function saveNewManager() {
    // adiciona dados do gerente no bd
}